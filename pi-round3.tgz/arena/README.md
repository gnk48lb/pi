# arena v0.2 — pi vs Claude Code 评测台

同一个模型、同一段提示词、同样的隔离环境，让 **pi** 和 **Claude Code** 各自把同一批编程任务做一遍，
然后由**隐藏的测试**判卷，并记录：通过率、成本、没走缓存的输入 token（含冷启动）、首个请求的提示词体积、耗时、LLM 调用数、
工具失败率、改动是否精简、是否卡死。纯标准库 Python（≥3.9），不装任何包。

这是 v0.x：先把“尺子”做准，不是正式比赛。第一轮（`day1`）用 2 道试点题量噪声、校准强度、量网关缓存的可靠度；
题库现在有 18 道（8 道开发题 + 4 道留出题 + 6 道难题），用 `suite` 一条命令跑一组题。

**v0.2 的变化（第 3 轮用）**：新增 `hard` 组（p13–p18，带分级隐藏检查，失败也有得分）；每次运行记下安全闸 / 保真闸 / 预算守卫在 stderr 写的事件
（报告里的 `G` / `B` 标记和 “guard extensions” 一节）；`suite` 加了 `--no-pack`（多批连跑时不每批都出一个结果文件，由脚本最后统一 `pack`）；
`run` / `suite` 加了 `--stop-after-infra N`（连续 N 次拿不到模型的回答就停下，退出码 4）与 `--redo-infra`（续跑时把被标 `I` 的运行作为新的尝试重做），
为的是长时间无人看守的批量运行里，网关挂了不会把剩下的运行白白烧光；
时间估计按难题调整；自测修了两处（参考解复制要保留可执行位；新版 Claude Code 2.1.311 拒绝裸 `sleep`，挂起测试改用复合命令），并新增一组“网关宕机保护”检查。

## 目录

```
arena.py            命令行入口（day1 / suite / pack / setup / selftest / smoke / calib / cacheprobe / tasks / run / report / prices）
arena_day1.py       day1 和 suite 共用的“多步骤、可断点续跑、最后打包成一个文件”的流程；pack：只打包
arena_core.py       隔离环境、运行 agent、判卷、结果行
arena_parse.py      把 pi 的 JSON 事件流 / Claude Code 的 stream-json 解析成统一格式
arena_probe.py      cacheprobe：不经过 agent，直接量网关的提示缓存
arena_report.py     报告：逐次明细、每题汇总、噪声(CV)、暂定 胜/平/负
arena_selftest.py   自测（对模拟网关，不花 token）
prices.json         唯一的价目表（所有 agent 共用，成本一律由 token 数重算）
mock/mock_server.py 模拟网关（OpenAI + Anthropic 两种协议，可脚本化“解题”）
tasks/p01 … p18     题库：repo/（给 agent 的）、hidden/（隐藏测试）、_ref/（参考解）、task.json
suite/<label>/     suite 每一批的步骤输出（<步骤>.log）和进度记录（state.json）
configs/            setup 生成（含你的网关占位符，不要上传，打包时也不会带上）
runs/<label>/       每次运行的日志和结果
day1/               day1 每一步的完整输出（<步骤>.log）和进度记录（state.json）
```

## 第一次使用：一条命令

在 WSL 里，把压缩包放到 `~/pi` 下解开，然后跑 `day1`：

```bash
cd ~/pi && tar xzf arena-v0.tar.gz && cd arena
tmux new -s arena               # 可选但推荐：关掉终端也不会中断（装了 tmux 的话）
python3 arena.py day1           # 约 2.5 小时，全程不需要输入；加 --quick 约 1.2 小时
```

它依次做这些事（每一步的完整输出都存在 `day1/<步骤>.log`）：

| 步骤 | 做什么 | 约耗时 |
|---|---|---|
| `setup` | 读取你现有的 pi / Claude Code 网关配置，生成“空白基线”配置。pi 的模型按“和 Claude Code 同一个 id”精确匹配（不会误选 `opencode-zen/...-free` 这类相似模型）。已有 `configs/setup.json` 就跳过 | 1 分钟 |
| `selftest` | 对模拟网关把整条流水线自测一遍，不花 token。全是 PASS 才算对 | 2 分钟 |
| `smoke` | 每个 agent 通过你的真实网关连问 3 次相同的 “Reply with exactly: PONG”：看首个请求多大、缓存命中多少，并自动判定 magpie 怎样汇报 Claude Code 的 token 用量（`input_tokens` 含不含缓存部分） | 2 分钟 |
| `cacheprobe` | 不经过 agent，直接量网关缓存：相同请求隔 1 秒到 160 秒后还命中吗？追加式对话（像 agent 循环那样）的命中率？有没有整段未命中？两种协议各测一遍 | 25 分钟（`--quick` 5 分钟） |
| `calib` | 同一道短题在两边所有“强度档位”下各跑 3 次（共 30 次短请求），看档位在线上到底差多少 | 20 分钟（`--quick` 7 分钟） |
| `pilot` | 2 题 × 2 个 agent × 5 次 = 20 次运行，隐藏测试判卷。量单次成本和各指标的噪声 | 约 90 分钟（`--quick` 3 次，约 55 分钟） |
| `report` | 生成 pilot 的报告：逐次明细、每题汇总、噪声表、暂定胜平负 | 1 分钟 |

最后它会把结果打成**一个文本文件** `arena-results-<时间>.txt`（还有一个 `.tgz`，内容相同，外加每个任务第一次运行的原始事件流），
并打印它的位置（在 WSL 里会同时打印 Windows 路径；`cd ~/pi/arena && explorer.exe .` 可以在资源管理器里打开该目录）。
**把这个 `.txt` 发给我就行**：它是纯文本，里面有各步骤的摘要、报告和全部数据行，没有密钥（`configs/` 不会被打包，疑似密钥的字符串也会被遮掉）。

### 中断、失败、重来

* 中途停了（Ctrl-C、关终端、重启）：再运行**同一条命令**。已完成的步骤会跳过，pilot 从断点继续。
* 某一步失败不会拖垮无关的步骤：`selftest` 失败会记录并继续；`smoke` 失败会跳过需要 agent 的步骤（`calib`、`pilot`、`report`），但 `cacheprobe` 照跑；只有 `setup` 失败才整体停止。无论如何最后都会打包，把结果文件发给我，我来看原因。
* 只跑某几步：`--only calib,pilot`；跳过某几步：`--skip selftest`；已完成但要重来：`--redo cacheprobe`（`--redo setup` 会连带重跑 `smoke`）。
* 想看进度：另开一个终端 `tail -f ~/pi/arena/day1/pilot.log`。想看某一次运行发生了什么：`runs/pilot1/<序号_agent_题_rN>/` 里有 `events.jsonl`（原始事件流）、`events.ts`（每行到达时间）、`stderr.txt`、`diff.patch`（agent 改了什么）、`verify.txt`（判卷输出）、`result.json`（归一化的一行）。
* 只重新打包：`python3 arena.py pack`（`--label pilot1` 只带某个标签的运行）。

### 单独运行某一步

`day1` 只是把下面这些命令按顺序串起来；需要调参或重跑某一步时可以单独用：

```bash
python3 arena.py setup        # --pi-model/--cc-model 等见 --help
python3 arena.py selftest
python3 arena.py smoke        # --repeat 3 --gap 4
python3 arena.py cacheprobe   # --quick；--tokens 8000 控制共享前缀大小
python3 arena.py calib        # --reps 3
python3 arena.py run --label pilot1 --tasks p01,p02 --agents pi,cc --reps 5
python3 arena.py report --label pilot1
python3 arena.py suite        # 见上一节：run 的“带检查、可续跑、自动打包”版本
```

`run` 是阻塞的，几十分钟到一两个小时：放进 tmux，或者 `nohup python3 arena.py run ... > pilot1.log 2>&1 &` 后台跑
（后台的用 `kill <pid>` 停，arena 会杀掉在跑的 agent 并收尾）；
中途停了加 `--resume` 继续（计划变了会拒绝，`--force` 可覆盖）。有运行没出结果时退出码是 3，`--resume` 会补跑。

## 任务套件：`suite`

`tasks/` 里有 18 道题，分三组：**dev（8 题）**拿来反复迭代、比较；**held（4 题）**是留出题，平时不看，只在大改动之后做一次总验收
（防止越调越对着开发题过拟合）；**hard（6 题）**是更难的题，单独成组、不混进 dev：dev 题基本都做对了，分不出质量，hard 题带分级隐藏检查（失败也有“通过了多少项”的得分）。
`python3 arena.py tasks` 列出全部，`tasks --check` 验证“没修时判负、参考解判正”（全部 18 题约 3 分钟）。

| 题 | 组 | 语言 | 类型 | 考什么 / 怎么判 |
|---|---|---|---|---|
| p01 pager | dev | Python | 修 bug | 按 README 把库修对；可见测试 + 隐藏规格测试 |
| p02 csvstat | dev | Node | 加功能 | 加 `--format json/table/text`（含表格排版细节）；隐藏规格测试 |
| p03 invtrack | dev | Python | 重构 | 函数和参数改名并保留弃用别名；隐藏测试查所有调用点和文档 |
| p04 shelfwise | dev | Node | 找根因 | 5 个测试失败，在分层代码里找真正的根因，不能只修表面 |
| p05 nightly | dev | Python | 性能 | 4 个慢函数提速且结果不变；隐藏测试带计时 |
| p06 logrotate-lite | dev | bash + make | 修构建 | `make test / lint / dist` 都要能用 |
| p07 discounts | dev | Python | 写测试 | 给没有测试的模块补测试，**用变异测试判**：测试得能抓住被故意改坏的实现 |
| p11 bookshop | dev | Python + SQLite | 加功能 | 软删除 + 恢复，跨 迁移/仓储/服务/API 四层；要写新的数据库迁移（旧迁移不许改），旧数据要保住 |
| p08 logsum | held | Node | 从零写 | 按规格写一个访问日志汇总命令行工具 |
| p09 notes_app | held | Python | 安全 | 路径穿越 + 符号链接逃逸，同时不能误伤正常用法 |
| p10 taskq | held | Python | 只读问答 | 文档是过时的，答 5 个问题；**判最终回答**对不对，并要求没改任何文件 |
| p12 spendsum | held | Node | 调试 | Excel 导出的 CSV 让程序崩了，堆栈指向的地方不是根因（BOM / CRLF / 引号 / 千分位，要一路追到解析层） |
| p13 semvr | hard | Python | 按规格实现 | 按 README 规格实现 npm 风格的版本区间（语法、预发布规则、错误处理），395 项隐藏检查 |
| p14 billing | hard | Node | 修 bug | 账单金额算错：8 个相互独立的 bug，只有 4 个表现为可见的失败，其余要对着规格读（日历、舍入规则） |
| p15 relay | hard | Python | 修“时好时坏” | 测试时过时不过：5 处顺序/哈希不确定性加一个干扰项；隐藏测试扫多个随机种子 |
| p16 checkout | hard | Node | 规格冲突 | README 与两个互相矛盾的可见测试冲突；**判最终回答**有没有讲清冲突，不是硬凑全绿 |
| p17 gateway | hard | Node | 字节保真 | 批量改 3 个必须逐字节保持其余内容的文件（混合 CRLF/LF、Latin-1、压缩 JSON）；pi 的 edit 工具会悄悄改坏这类文件 |
| p18 shopcore | hard | Python | 跨文件重构 | 给定价函数加一个必填关键字参数，调用方藏在别名、注册表、partial 和 getattr 后面，可见测试没覆盖所有入口 |

```bash
python3 arena.py suite                  # 检查题目 → 8 道 dev 题 × pi/Claude Code × 3 次 = 48 次运行 → 报告 → 打包成一个结果文件
python3 arena.py suite --label v1 --agents pi --pi-config ~/pi/variants/v1     # 以后：只跑 pi 的某个变体
python3 arena.py suite --tasks held --label held1                                # 留出题，少用
python3 arena.py suite --tasks hard --label hard1 --agents pi --timeout 1200     # 难题：每次要几分钟，超时放宽
python3 arena.py suite --label x --agents pi --skip tasks --no-pack              # 脚本里连跑多批：不重复检查题目、不每批都出结果文件
python3 arena.py pack --label x --label y                                         # 最后统一打包
```

* dev 题约 1–1.5 小时（每次运行平均 1–2 分钟，按题目难度浮动），hard 题每次运行估计 3–8 分钟（还没有真实数据），全程不需要输入；放进 tmux 或 `nohup` 里跑更稳。
  中断后再运行**同一条命令**：做完的步骤跳过，`run` 用 `--resume` 从断点继续。进度在 `suite/<label>/state.json`，每步输出在 `suite/<label>/<步骤>.log`。
* 每个 `--label` 是独立的一批（各有各的进度）。选项和 `run` 一样（`--reps`、`--agents`、`--pi-config`、`--pi-thinking`……）。
  `suite` 要求先跑过 `day1`（它负责 `setup`）。
* 结束时打包成 **一个** `arena-results-<时间>.txt`（+ `.tgz`），内容只关于这一批：报告、数据行、失败运行的判卷备注，没有密钥。**把它发给我**。
* 报告里新增 **failing runs: why** 一节：每次失败的原因和判卷脚本的备注（比如“答对 4/5，第 2 题错”“新增回归测试 +4”），不用翻日志。
* **调度顺序是“按题分组”**：同一道题的 3 次重复紧挨着跑（两个 agent 交替先后手）。紧挨着跑时网关缓存是热的；
  如果先把所有题各跑一遍再重复，两次之间隔太久，量到的就是缓存的存活时间，不是 harness 的好坏。每题第一次运行是冷启动，所以每题至少跑 3 次，中位数才不受它影响。
* **难度还没校准**：dev / held 的 12 题 suite1 已经跑过（dev 题基本全过，所以才加了 hard 组）；hard 的 6 题是在容器里做的，
  只能验证“参考解过、没修时不过、常见错误解和脚本化模拟不过”，真实的通过率要等你跑一轮才知道（目标 30–80%）。
  如果某题所有配置都 100% 通过或都 0%，它就没有区分度，会记为发现。
* **得分**：报告的 `checks` 列是验证器统计的“通过的检查项占比”（取均值），hard 题失败时也有分；`pass` 仍然要求全部通过。

### 题目怎么写（要加新题时）

一道题是 `tasks/<id>/` 下的一个目录：`repo/`（原样复制给 agent，`git init` 后成为基线）、`hidden/`（agent 看不到，判卷时才拷进工作区）、
`_ref/files/`（参考解，覆盖到 repo 上）、`task.json`：

* `split`（dev / held / hard）、`lang`、`category`、`requires`（需要的程序，机器上没有就跳过这题）、`prompt`（原样给 agent 的提示词）。
* `protected`：改了就直接判负的文件（测试、迁移、数据文件）；`verify`：判卷命令列表（在工作区里用 `bash -c` 运行，全部退出码 0 才算过）；
  `hidden_dir`、`verify_timeout`、`visible_test_cmd`；`ref_diff_lines`：参考解的改动行数（用于 minimality），`tasks --check --write-ref` 自动填。
* 问答类题目：agent 的最终回答会写进文件，路径通过环境变量 `ARENA_FINAL` 交给判卷命令；参考答案放 `_ref/final.txt`。
* 判卷命令可以打印 `ARENA_NOTE: 任意一行说明`，这些说明会出现在报告的 “failing runs” 一节（最多 8 行）。
* 判卷命令的输出里如果有 `Ran N tests` / `# tests N` 这类行，会被用来统计“失败 x/y 个测试”。

## 公平与隔离：它做了什么

| 做法 | 为什么 |
|---|---|
| 每次运行前清空 agent 自己的 `HOME`、`TMPDIR`、配置目录（`PI_CODING_AGENT_DIR` / `CLAUDE_CONFIG_DIR`） | 你自己的 AGENTS.md、扩展、skills、记忆、历史都进不来；基线 = 空白配置 |
| 这些目录的**路径每次相同**：`/tmp/arena-ws-env/<agent>/…`（内容每次清空） | agent 会把自己的路径写进系统提示（Claude Code 的记忆目录、pi 的 AGENTS.md 路径）。路径每次不同，每次运行的第一个请求就会白白丢掉缓存，和 harness 好坏无关。真实安装里 `~/.claude`、`~/.pi` 也是固定的 |
| 基线提交的日期固定（hash 每次相同） | Claude Code 会把最近的 git 提交（`f37febe baseline`）写进第一条消息；hash 随时间变，缓存又会断一次 |
| 同一时间只允许一个跑 agent 的 arena 命令（锁文件 `/tmp/arena-ws-env/.lock`） | 工作区和 agent 目录路径固定，两个同时跑会互相覆盖。要并行请给另一个命令单独的 `--ws-root` |
| 环境变量白名单，只继承 `PATH` | 你 shell 里的各种 key 不会泄漏给 agent |
| 代理变量指向一个必拒绝的端口，只放行 `127.0.0.1` | 评测期间 agent 联不了外网，只能找本地网关 |
| 工作区固定在 `/tmp/arena-ws/<题>`，每次重建并 `git init` 提交基线 | 两个 agent 的 cwd 完全相同；便于量 diff |
| 提示词原样相同；无 `--max-turns`；同样的超时 | 规则对称 |
| 交错运行 A B / B A / A B …（按 重复×题 轮换先后手）；同一道题的重复紧挨着跑 | 抵消时间漂移（网关忙闲、缓存预热）；紧挨着跑才不会量成缓存的存活时间 |
| 判卷在 agent 退出之后，用 agent 看不到的隐藏测试；改动受保护的测试文件直接判负 | 防作弊、防“改测试蒙混” |
| 成本一律用 `prices.json` 按 token 重算；agent 自己报的成本只作参考 | Claude Code 不认识这个模型，自报的价格是错的 |
| 运行结束后杀掉整个进程组，再按环境标记扫一遍逃逸的子进程 | 不留后台进程污染下一次 |
| Claude Code **不**设 `CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC` | 实测它会悄悄去掉一个工具、少约 2.3k 提示词，不再是“开箱即用”的行为 |
| 默认工具集：各用各的默认（Claude Code 去掉 WebFetch/WebSearch）；`--toolset aligned` 则双方都只留 read/bash/edit/write | 先比整机，再比“循环和提示词本身”。注意：较新的 Claude Code（实测 2.1.304）即使加了 `--tools` 也还会多发一个占位工具 `DeferredToolPlaceholder`，去不掉；报告里 `tools_exposed` 会如实显示 |
| Claude Code 带 `--include-partial-messages`（只改输出，不改发给模型的请求） | 读取每次 API 调用的原始用量。网关若把用量只放在流末尾，不加这个开关逐次数据会全是 0 |
| `smoke` 判定网关的 `input_tokens` 含不含缓存，写入 `configs/setup.json`，之后 `run`/`calib` 按此解读 | 解读错了，Claude Code 的命中率和成本都会错（magpie 的实测是“只计未命中部分”） |
| `cacheprobe` 直接用 HTTP 访问网关，不走代理 | 量的是网关本身的缓存，不掺进 agent 的行为 |

## 强度（effort）怎么对齐

默认值实测下来**已经对齐**（day1 的 calib 加 pilot 数据）：

* **pi**：内置默认是 `thinking=medium`，但会被 clamp 到这个模型支持的档位（只有 low / high / max），所以实际生效的是 **high**。
  线上映射：off→low、low→low、medium→high、high→high、xhigh→max（`off` 关不掉推理）。
  只有模型条目写了 `reasoning: true` 才会发 `reasoning_effort`。每行结果的 `thinking_level` 记录的是实际生效的档位。
* **Claude Code**：默认发 `thinking: adaptive` + `effort=high`。
* magpie 怎么把 Claude Code 的 effort 翻译给 DeepSeek 看不到（要确认得录制代理，记在路线图里）。

所以默认对默认就是 high 对 high，`--pi-thinking X --cc-effort Y` 只在想专门比较别的档位时才用。
`calib` 用同一道短题测每个档位的输出 token（含推理），但它是单次采样，噪声大，只能当粗略参考，不要拿它精调。

注意：Claude Code 报的 `thinking_tokens` 不可信（自测里模拟网关发了推理块它仍报 0），比较推理量请看 `output tokens`。

## 指标

| 指标 | 含义 | 好的方向 |
|---|---|---|
| pass rate | 隐藏验收 + 可见测试全过，且未超时、未改受保护文件 | 高 |
| cost | 由 token 数和 `prices.json` 重算，单位 USD | 低 |
| uncached input tokens | 没走缓存的输入 token（`input + cache_write`）。分开看：**首个请求**（冷启动要付整段提示词，热启动几乎不付）和**首个请求之后**的所有请求（每轮新增的工具结果、助手自己的上一条消息，加上网关留下的未缓存尾巴） | 低 |
| first-request prompt tokens | 第一个请求的提示词体积（系统提示 + 工具定义） | 低 |
| total prompt tokens / output tokens | 全程累计 | 低 |
| LLM calls | 主线程的 LLM 请求数 | 低 |
| wall seconds | 墙钟时间（含启动） | 低 |
| tool error rate | 工具调用里报错的比例 | 低 |
| minimality | 非测试文件的 diff 行数 ÷ 参考解的 diff 行数 | 低（≈1 最好） |
| timeout rate | 撞到超时被杀 | 低 |

结果行里的 flags：`T` 超时，`I` 网关/基础设施错误（会自动重跑一次，报告里仍标出），`X` 改了受保护测试，
`E` agent 报错，`C` 出现缓存断崖（本该命中的上一轮前缀没命中，阈值 `≥ max(3000, 40%)` tokens），`K` 冷启动（第一个请求的命中率 < 50%），
`G` 安全闸或保真闸拦下了一次工具调用，`B` 预算守卫提醒或中止过（这两项来自 v1 扩展写在 stderr 的一行日志，只在非交互模式有；报告里 “guard extensions” 一节列出每个配置的次数和被拦的命令）。

**命中率只当诊断看**（表里的 `hit` / `1st hit` 列）：它和提示词大小有关，一个小提示词每轮新增同样多的 token，命中率天然比大提示词低，不代表缓存更差。真正比较的是上面的未缓存 token 数。报告里 “cache warmth” 表列出每个任务每个 agent 有几次冷启动、冷启动比热启动多付多少未缓存 token；如果同一道题的重复运行几乎全是冷启动，会警告“前缀不稳定”（系统提示或工具列表的前面有东西每次都在变）——这就是缓存回归的哨兵。
冷启动的那几次不进 noise 表（五次里有一次冷启动，会让所有 token 指标的变异系数虚高）；W/T/L 取中位数，所以**每题至少跑 3 次**，中位数才不会被那一次冷启动带偏。

`report` 里的 **noise** 表给出各指标的变异系数（重复运行之间的波动），“暂定 W/T/L”用的平手带宽是猜的，
等试点数据出来再按噪声改（`--bands cost=0.2,wall=0.3` 可覆盖）。题目太少时这张表只是在演练流程，不是结论。

## 已知局限（v0）

* **不是沙箱**：agent 以你的账号、免确认权限运行（pi 本来就没有确认；Claude Code 用 `bypassPermissions`）。
  `HOME`/环境变量/代理做了隔离，但一个铁了心的 agent 仍可能 `rm -rf` 你有权限的地方。试点题很温和，别把重要文件放进 `/tmp/arena-ws`。
* **网关缓存的可靠度**：早先在 magpie 上见过“完全相同的请求隔几秒却一点缓存都没命中”；10-21 的 `cacheprobe`（104 个请求，间隔最长 160 秒，两种协议）没有再出现整段未命中、也没有随间隔衰减。实测缓存粒度是 **128 token**（pilot 的 179 次调用加 probe 的 104 次，命中数全是 128 的倍数），每个请求末尾平均有 128–255 个 token 留在缓存之外，这是固有的。
  成本类指标仍然要看多次运行的中位数，波动有多大由 noise 表来量。
* **缓存跨次预热**：同一 agent 同一题的相邻两次，第一个请求逐字节相同（目录路径、基线 hash 都固定了，自测会验证），
  所以在网关侧是热的（DeepSeek 磁盘缓存），和你平时在同一个项目里连开两次会话一样。双方对称，但每题的第 1 次比后面更冷（报告里标 `K`）。
  试点实测（你的 WSL，10-21）：每题第 1 次运行 Claude Code 要付约 1.7 万个未缓存输入 token（约 $0.0026），pi 约 1.1–1.6 千；
  之后的重复两边都只付约 240。换题时两边能共用的前缀都只有 512 token（大概是聊天模板自带的部分），
  Claude Code 是整段提示词都从头变（猜测：第一个系统块里有一个按首条消息算出来的指纹，**未验证**），pi 只有 cwd 一行不同。
  这是 pi 在“频繁开新会话”场景里的结构性优势，但在长会话里会被摊薄。
* **价格表**只有 DeepSeek V4.1 Flash 的牌价，高峰时段的 ×2 没建模（请在非高峰时段跑）。
* 试点只有 2 道题，现在有 18 道（见上），hard 组的难度没校准。试点的噪声数据（去掉冷启动后）：成本 CV 约 19%、输出 token 约 26%、未缓存输入约 11%、墙钟约 16%——所以单题只能看大方向，要靠多题多次的合计才分得出 15% 左右的差别：
  8 题 × 3 次大约能分出 12–15% 的系统性差别，再小的差别要 4 倍的运行量。
* 只支持 Linux / WSL（用了进程组、`/proc`）。

## 常见问题

* `setup` 说某个程序在新 HOME 下起不来：它会自动退回真实 HOME 再试，并记在 `configs/setup.json`（配置目录仍然隔离）。
* `setup` 拒绝了 `/mnt/...` 下的 pi 或 claude：那是 Windows 的程序；用 WSL 里的 Linux 安装（`--pi-bin` / `--cc-bin` 指定路径）。
* pi 的 apiKey 如果是环境变量名而不是字面量：arena 不透传环境变量，请在 models.json 里写字面量（本地网关的占位符即可）。
* 网关限流/报错：该次运行会被标 `I` 并自动重跑一次（`--retry-infra N` 可调）。大批量时建议错峰。
  `--stop-after-infra N`：连续 N 次运行都拿不到模型的回答（网关挂了、额度用完、agent 起不来）就停下，退出码 4，
  不再把剩下的运行白白烧光；网关恢复后用 `--resume --redo-infra` 继续，被标 `I` 的运行会作为新的尝试重做
  （旧的那次留在磁盘上，报告里算“被取代的尝试”）。默认两个开关都不开；`round3.sh` 已经带上。
* 改了版本：每一行都记录了 pi / claude 的版本号；批次中途版本变了报告会警告。Claude Code 已锁定自动更新。
* `--keep-dirs` 把每次运行的 HOME 和配置目录留在 `runs/<label>/<run>/env/`（很大，只在排查时用；不会被打包）。
* 提示 “another arena command (...) is already using the workspace root”：另一个 `day1`/`run`/`smoke`/`calib` 还在跑
  （比如别的终端窗口、tmux 里的会话）。等它结束或 Ctrl-C 它；进程一结束锁就自动释放，不会残留。
* 结果文件怎么拿出 WSL：`day1`/`pack` 结束时会打印 Windows 路径（`\\wsl.localhost\...`），在资源管理器地址栏粘贴即可；或者 `explorer.exe .`。

## 以后：对比 pi 的一个定制变体

变体 = 一个目录，里面只放你要改的东西，叠加在空白基线之上（模型/网关配置保持不变）。目录结构就是 pi 的 agent 目录：
`AGENTS.md`、`APPEND_SYSTEM.md`、`SYSTEM.md`、`extensions/`、`skills/`、`prompts/`、`mcp.json`，以及 `settings.json`
（和基线的 settings.json 逐键合并，变体里的键优先）。

```bash
python3 arena.py suite --label base                                                         # 基线（pi 和 claude 一起，开发题 × 3 次）
python3 arena.py suite --label v1 --agents pi --pi-config ~/pi/variants/v1                  # 只跑 pi 变体
python3 arena.py suite --label v2 --agents pi --pi-extra "-e /绝对路径/ext.ts"               # 也可以只加一个扩展（用绝对路径）
python3 arena.py report --label base --label v1 --label v2                                  # 并排比较（suite 只报告它自己那一批）
python3 arena.py pack                                                                       # 把这些一起打包发我
```

报告会把同一个 agent 的不同配置分成不同的“臂”（`pi@base`、`pi@v1` …），分别对 claude 比，
并且把 `v1` 对 `base` 比（变体 vs 基线）。每一行结果都记录了变体目录的指纹和额外参数；
`--resume` 时如果变体内容变了会拒绝继续。局限：基线与变体是分开的两批，不是同一轮里交错跑的，
网关忙闲造成的耗时漂移不会被抵消（token / 缓存 / 成本不受影响）；v1 版本会支持在同一轮里交错多条“臂”。
